#include "SdFat.h"

namespace Bootloader {
    void format_sd_fat32(Sd2Card& card);
}