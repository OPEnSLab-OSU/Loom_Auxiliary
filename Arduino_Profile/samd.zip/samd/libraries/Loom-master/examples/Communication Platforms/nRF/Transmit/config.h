"{\
	'general':\
	{\
		'name':'Device',\
		'instance':1,\
		'interval':2000\
	},\
	'components':[\
		{\
			'name':'Analog',\
			'params': 'default'\
		},\
		{\
			'name':'nRF',\
			'params': 'default'\
		}\
	]\
}"
