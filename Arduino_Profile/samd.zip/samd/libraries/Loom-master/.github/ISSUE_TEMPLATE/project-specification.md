---
name: Project Specification
about: Contains information needed to develop a deployment ready device with Loom.
title: ''
labels: Project Specification
assignees: ''

---

**Project Name**

**Project Description**
what the project aims to accomplish

**Hardware List**
* List of hardware project will use
* [Link to Implementation Request issues associated with dependent hardware]()

**Additional Project Requirements**
* Things the project must be able to do to succeed
* The more detail, the more we will be able to aid in development
