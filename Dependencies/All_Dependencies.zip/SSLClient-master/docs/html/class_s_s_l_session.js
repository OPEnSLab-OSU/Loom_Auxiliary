var class_s_s_l_session =
[
    [ "SSLSession", "class_s_s_l_session.html#ae05648200cea66577f024d5d09a6fcbb", null ],
    [ "clear_parameters", "class_s_s_l_session.html#a3305941fa615f7134526b718917716ee", null ],
    [ "get_hostname", "class_s_s_l_session.html#a825373c5ba1aa6c45e74dc8a72b21820", null ],
    [ "get_ip", "class_s_s_l_session.html#a878e1e8788634c5c42778369fbf7bab0", null ],
    [ "is_valid_session", "class_s_s_l_session.html#a0c36cee72cfa862b7d4b2f5c112d5076", null ],
    [ "operator=", "class_s_s_l_session.html#abb3f7bbe70e3a59f9ce492c55507f36f", null ],
    [ "set_parameters", "class_s_s_l_session.html#a2fa15ce0b7caae25dfb567954175257e", null ],
    [ "to_br_session", "class_s_s_l_session.html#acbe6549b55d50541d09a16f770e65afc", null ]
];