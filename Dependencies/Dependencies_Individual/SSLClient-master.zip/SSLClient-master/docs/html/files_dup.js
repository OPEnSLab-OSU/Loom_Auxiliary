var files_dup =
[
    [ "examples", "dir_d28a4824dc47e487b107a5db32ef43c4.html", "dir_d28a4824dc47e487b107a5db32ef43c4" ],
    [ "readme", "dir_dfc5a9f91fbfb9426c406a3f10131a54.html", "dir_dfc5a9f91fbfb9426c406a3f10131a54" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ]
];