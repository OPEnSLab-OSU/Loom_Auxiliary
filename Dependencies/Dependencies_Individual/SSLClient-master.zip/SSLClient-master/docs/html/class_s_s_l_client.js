var class_s_s_l_client =
[
    [ "DebugLevel", "class_s_s_l_client.html#af632625f8d247f3885c81e1f05043ad1", [
      [ "SSL_NONE", "class_s_s_l_client.html#af632625f8d247f3885c81e1f05043ad1a24122d1e1bb724237f305a0b4a21ff75", null ],
      [ "SSL_ERROR", "class_s_s_l_client.html#af632625f8d247f3885c81e1f05043ad1a199742ec5c99c72d9cede1fda0f125c5", null ],
      [ "SSL_WARN", "class_s_s_l_client.html#af632625f8d247f3885c81e1f05043ad1a26f3e5f1481f3ea22ea4ab5370b0fa97", null ],
      [ "SSL_INFO", "class_s_s_l_client.html#af632625f8d247f3885c81e1f05043ad1a8d5f7561f9cc0a2f3e5f362b02f4a5b2", null ]
    ] ],
    [ "Error", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6cea", [
      [ "SSL_OK", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaa18dbddc0a3d4a94ee0f298fe55a06a94", null ],
      [ "SSL_CLIENT_CONNECT_FAIL", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaa7510402478ffbecd6e1aa3811b175cfd", null ],
      [ "SSL_BR_CONNECT_FAIL", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaa6a9cc2412a53b5981e937a41523eece5", null ],
      [ "SSL_CLIENT_WRTIE_ERROR", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaab8581e1172fbf15067d435706d3a03a8", null ],
      [ "SSL_BR_WRITE_ERROR", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaa37bef298be71b84a57e59fadbfbd9016", null ],
      [ "SSL_INTERNAL_ERROR", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaaf66f8d5f6601f9e7607b78bf7a07fc84", null ],
      [ "SSL_OUT_OF_MEMORY", "class_s_s_l_client.html#a48239f60f1b4318cc112706fc40c6ceaa0a4f8af0226cf29ede8f6fe4a9047b08", null ]
    ] ],
    [ "SSLClient", "class_s_s_l_client.html#a68f026a625ca1ccd1aba87bb6e670376", null ],
    [ "available", "class_s_s_l_client.html#a0e775669b4a040fbd3f281dcbcd2de78", null ],
    [ "connect", "class_s_s_l_client.html#ab97c0745f65a6c6009ac938b3b9912c3", null ],
    [ "connect", "class_s_s_l_client.html#a248a5152cc3c3e7666bf5443bfd57c90", null ],
    [ "connected", "class_s_s_l_client.html#a5488f01ccfddfd9e41f54dfbda48bcae", null ],
    [ "flush", "class_s_s_l_client.html#aaf2192a6621fdf2f89cc26a9a1584f8c", null ],
    [ "getClient", "class_s_s_l_client.html#a9a4e9c9877ab73cf7e82d6942cc7db21", null ],
    [ "getSession", "class_s_s_l_client.html#a2bd012ef6f01df9694ba9fd0a3c227c3", null ],
    [ "getSessionCount", "class_s_s_l_client.html#ae3f9e6f8e8a50e520c936239abecfd22", null ],
    [ "getTimeout", "class_s_s_l_client.html#a2a178251978e0622f7e241da702ae498", null ],
    [ "operator bool", "class_s_s_l_client.html#a4192ee3562c4806d4a6829356ca2636b", null ],
    [ "peek", "class_s_s_l_client.html#a0c0b6f2ad25701d1e45adb613d072d86", null ],
    [ "read", "class_s_s_l_client.html#a4c5420541a06213133ae308a3bca1c95", null ],
    [ "read", "class_s_s_l_client.html#aef1b52f4ad9633126cb68739175920eb", null ],
    [ "removeSession", "class_s_s_l_client.html#ad5d9d8a4187a3f8918bf66af83e733c4", null ],
    [ "setMutualAuthParams", "class_s_s_l_client.html#a9e7ce7f8a72d7cdc071be3fa7a4c8f29", null ],
    [ "setTimeout", "class_s_s_l_client.html#a8da354f30537c1064d554921937a73ae", null ],
    [ "stop", "class_s_s_l_client.html#ad8ed697371748e31e01c3f697bc36cbe", null ],
    [ "write", "class_s_s_l_client.html#a03c7926938acd57cfc3b982edf725a86", null ],
    [ "write", "class_s_s_l_client.html#a7343a58457b4659f83b61cac1f442c3d", null ]
];