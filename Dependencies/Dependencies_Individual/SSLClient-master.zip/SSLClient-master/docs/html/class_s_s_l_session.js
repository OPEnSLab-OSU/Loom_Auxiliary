var class_s_s_l_session =
[
    [ "SSLSession", "class_s_s_l_session.html#a0c8e01b0944c1f4b0ec6d4c423c95b74", null ],
    [ "get_hostname", "class_s_s_l_session.html#a825373c5ba1aa6c45e74dc8a72b21820", null ],
    [ "to_br_session", "class_s_s_l_session.html#acbe6549b55d50541d09a16f770e65afc", null ]
];