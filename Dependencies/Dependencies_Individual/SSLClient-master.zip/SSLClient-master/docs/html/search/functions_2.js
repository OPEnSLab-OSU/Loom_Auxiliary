var searchData=
[
  ['connect',['connect',['../class_s_s_l_client.html#ab97c0745f65a6c6009ac938b3b9912c3',1,'SSLClient::connect(IPAddress ip, uint16_t port) override'],['../class_s_s_l_client.html#a248a5152cc3c3e7666bf5443bfd57c90',1,'SSLClient::connect(const char *host, uint16_t port) override']]],
  ['connected',['connected',['../class_s_s_l_client.html#a5488f01ccfddfd9e41f54dfbda48bcae',1,'SSLClient']]]
];
