var indexSectionsWithContent =
{
  0: "_abcdefgimoprstuvw",
  1: "s",
  2: "s",
  3: "cerst",
  4: "abcfgmoprstw",
  5: "bceiv",
  6: "de",
  7: "s",
  8: "_cgpstu",
  9: "st"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

