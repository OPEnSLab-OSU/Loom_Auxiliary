var searchData=
[
  ['write',['write',['../class_s_s_l_client.html#a03c7926938acd57cfc3b982edf725a86',1,'SSLClient::write(const uint8_t *buf, size_t size) override'],['../class_s_s_l_client.html#a7343a58457b4659f83b61cac1f442c3d',1,'SSLClient::write(uint8_t b) override']]]
];
