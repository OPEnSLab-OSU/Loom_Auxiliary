var time__macros_8h =
[
    [ "__TIME_DAYS__", "time__macros_8h.html#a7f2cdee2eebbccd45c179a50a0bbabcf", null ],
    [ "__TIME_HOURS__", "time__macros_8h.html#a2488d1ddab7e5fa119da3421462231c4", null ],
    [ "__TIME_MINUTES__", "time__macros_8h.html#ab3592442029a102b388fafeadc4a6ab8", null ],
    [ "__TIME_MONTH__", "time__macros_8h.html#ac8f6b75d9e04634818984ba400d0dee1", null ],
    [ "__TIME_SECONDS__", "time__macros_8h.html#a38ac93dd8bfe385ff915a82c92bbfc97", null ],
    [ "__TIME_YEARS__", "time__macros_8h.html#a56482fcc86a55713dee595c2092ed376", null ],
    [ "_UNIX_TIMESTAMP", "time__macros_8h.html#a868143e0521daf07b25a2f3947cf54a3", null ],
    [ "_UNIX_TIMESTAMP_FDAY", "time__macros_8h.html#ab6c76862964ff7e543fd9d5807b2fa79", null ],
    [ "_UNIX_TIMESTAMP_YDAY", "time__macros_8h.html#a5ab60a7e3e1b6e0a919b3a37bc0d4b97", null ],
    [ "CONV_STR2DEC_1", "time__macros_8h.html#ae0574ced3f997b97d357c1cb68000e3a", null ],
    [ "CONV_STR2DEC_2", "time__macros_8h.html#ae90924c33a05839b3eb1426472f40eb3", null ],
    [ "CONV_STR2DEC_3", "time__macros_8h.html#aad01b5fb233c0091aff2a837a8de32f4", null ],
    [ "CONV_STR2DEC_4", "time__macros_8h.html#a9da779a8ca64782ea49babce14122d34", null ],
    [ "GET_MONTH", "time__macros_8h.html#a4dbe4cf7c879a2cdac386ce72c5e5994", null ],
    [ "PST_OFFSET", "time__macros_8h.html#a243cf438274412bbecf4b8d5eeb02ccb", null ],
    [ "SEC_PER_DAY", "time__macros_8h.html#a3aaee30ddedb3f6675aac341a66e39e2", null ],
    [ "SEC_PER_HOUR", "time__macros_8h.html#a2d540510d5860d7f190d13124956bc57", null ],
    [ "SEC_PER_MIN", "time__macros_8h.html#ac47b302f1b8d2a7a9c035c417247be76", null ],
    [ "SEC_PER_YEAR", "time__macros_8h.html#a8cd8e04105fec7cd442d078c303e46b9", null ],
    [ "UNIX_TIMESTAMP", "time__macros_8h.html#a04e76e262f0920441e5f0c5552e83487", null ],
    [ "UNIX_TIMESTAMP_UTC", "time__macros_8h.html#a2af3d1d741ae2b49627adf56bbc95dc3", null ]
];